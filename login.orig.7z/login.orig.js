const passwordInput = document.getElementById("pwd-ipt");
const rememberCheckbox = document.getElementById("remember-cb");
const animeLoginButton =  document.getElementById("anime-login-btn");
const mangaLoginButton =  document.getElementById("manga-login-btn");
const isAnime = animeLoginButton !== null;

mangaLoginButton?.addEventListener('click', () => {login();})
animeLoginButton?.addEventListener('click', () => {login();})

function tryRemember() {
    let saved_pwd = localStorage.getItem("pwd");

    if (saved_pwd) {
        login(saved_pwd);
    } else {
        showLogin();
    }
}

function showLogin() {
    document.getElementById("login-sctn").style.display = "flex";
}



function login(password = null) {
    let data = new FormData();

    if (!password && passwordInput.value.length <= 2) {
        passwordInput.className = "error";
        passwordInput.value = "";
        return;
    }

    password = password ?? passwordInput.value;
    data.append("password", password);
    passwordInput.value = "";

    let xhr = new XMLHttpRequest()
    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 201) {
                if (rememberCheckbox.checked) {
                    localStorage.setItem("pwd", password);
                }
                document.body.innerHTML = xhr.responseText;
            } else {
                showLogin();
                passwordInput.className = "error";
            }
        }
    }

    if(isAnime) {
        xhr.open('POST', atob("aHR0cHM6Ly90cnlvbC5kZG5zLm5ldC9raGFuL2F1dGhfYW5pbWUucGhw"), true);
    }
    else {
        xhr.open('POST', atob("aHR0cHM6Ly90cnlvbC5kZG5zLm5ldC9raGFuL2F1dGhfbWFuZ2EucGhw"), true);
    }
    xhr.send(data);
}

tryRemember();